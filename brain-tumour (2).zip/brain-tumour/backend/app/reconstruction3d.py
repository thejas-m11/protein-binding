import SimpleITK as sitk
import numpy as np
from skimage import measure
import logging

logger = logging.getLogger(__name__)

class Reconstructor3D:
    def __init__(self):
        self.slice_thickness = 3.0  # mm
        self.pixel_spacing = [1.0, 1.0]  # mm
        self._volume = None
        self._mask = None
        self.logger = logging.getLogger(__name__)

    def process_slices(self, slices):
        """Process multiple slices and calculate metrics"""
        try:
            if not slices:
                raise ValueError("No slices provided")

            # Handle single slice case
            if len(slices) == 1:
                self.logger.info("Processing single slice")
                # Duplicate the slice to create minimal 3D volume
                slices = [slices[0]] * 2

            # Stack 2D slices into 3D volume
            volume = np.stack(slices, axis=0)
            self.logger.info(f"Created volume with shape: {volume.shape}")

            # Convert to SimpleITK image
            self._volume = sitk.GetImageFromArray(volume)
            self._volume.SetSpacing([
                self.pixel_spacing[0],
                self.pixel_spacing[1],
                self.slice_thickness
            ])

            # Segment tumor
            success = self._segment_tumor()
            if not success:
                raise ValueError("Tumor segmentation failed")

            # Calculate metrics
            metrics = self._calculate_metrics()
            if not metrics:
                raise ValueError("Failed to calculate metrics")

            self.logger.info("Successfully processed volume")
            
            return {
                'success': True,
                'metrics': metrics,
                'volume_data': {
                    'dimensions': {
                        'width': int(volume.shape[2]),
                        'height': int(volume.shape[1]),
                        'depth': len(slices)
                    },
                    'spacing': {
                        'x': float(self.pixel_spacing[0]),
                        'y': float(self.pixel_spacing[1]),
                        'z': float(self.slice_thickness)
                    }
                }
            }

        except Exception as e:
            self.logger.error(f"Error processing slices: {str(e)}")
            raise

    def _segment_tumor(self):
        """Segment tumor from the volume"""
        try:
            # Apply Otsu thresholding
            otsu = sitk.OtsuThresholdImageFilter()
            binary = otsu.Execute(self._volume)

            # Connected component analysis
            cc = sitk.ConnectedComponentImageFilter()
            labeled = cc.Execute(binary)

            # Get largest component
            label_stats = sitk.LabelStatisticsImageFilter()
            label_stats.Execute(labeled, self._volume)
            
            largest_label = max(label_stats.GetLabels(), 
                              key=lambda x: label_stats.GetCount(x))

            self._mask = labeled == largest_label
            return True

        except Exception as e:
            logger.error(f"Segmentation failed: {str(e)}")
            return False

    def _calculate_metrics(self):
        """Calculate tumor measurements"""
        try:
            if self._mask is None:
                raise ValueError("No segmentation mask available")

            # Get label statistics
            label_stats = sitk.LabelStatisticsImageFilter()
            label_stats.Execute(self._mask, self._volume)

            # Get shape statistics
            shape_stats = sitk.LabelShapeStatisticsImageFilter()
            shape_stats.Execute(self._mask)

            # Get bounding box - shape stats uses (start_x, end_x, start_y, end_y, start_z, end_z)
            bbox = shape_stats.GetBoundingBox(1)
            spacing = self._volume.GetSpacing()

            # Calculate volume directly from voxel count and spacing
            voxel_count = label_stats.GetCount(1)  # Get number of voxels in tumor
            voxel_volume = np.prod(spacing)  # Volume of one voxel in mm³
            volume = voxel_count * voxel_volume

            # Calculate surface area
            surface_area = self._calculate_surface_area()

            # Calculate physical dimensions from bounding box
            physical_dims = {
                'width': (bbox[1] - bbox[0]) * spacing[0],
                'height': (bbox[3] - bbox[2]) * spacing[1],
                'depth': (bbox[5] - bbox[4]) * spacing[2]
            }

            metrics = {
                'volume_mm3': float(volume),
                'surface_area_mm2': float(surface_area),
                'depth_mm': float(physical_dims['depth']),
                'width_mm': float(physical_dims['width']),
                'height_mm': float(physical_dims['height']),
                'num_slices': int(bbox[5] - bbox[4] + 1),
                'center_slice': int((bbox[5] + bbox[4]) // 2),
                'tumor_intensity': {
                    'mean': float(label_stats.GetMean(1)),
                    'std': float(label_stats.GetSigma(1)),
                    'min': float(label_stats.GetMinimum(1)),
                    'max': float(label_stats.GetMaximum(1))
                }
            }

            logger.info(f"Calculated metrics: {metrics}")
            return metrics

        except Exception as e:
            logger.error(f"Metrics calculation failed: {str(e)}")
            raise

    def _calculate_surface_area(self):
        """Calculate surface area using marching cubes"""
        try:
            mask_np = sitk.GetArrayFromImage(self._mask)
            verts, faces, _, _ = measure.marching_cubes(mask_np)

            # Calculate area of each triangle
            def triangle_area(triangle):
                a = np.linalg.norm(triangle[1] - triangle[0])
                b = np.linalg.norm(triangle[2] - triangle[1])
                c = np.linalg.norm(triangle[0] - triangle[2])
                s = (a + b + c) / 2
                return np.sqrt(s * (s - a) * (s - b) * (s - c))

            # Sum areas and convert to physical units
            total_area = sum(triangle_area(verts[face]) for face in faces)
            physical_area = total_area * self.pixel_spacing[0] * self.pixel_spacing[1]

            return physical_area

        except Exception as e:
            logger.error(f"Surface area calculation failed: {str(e)}")
            return 0.0