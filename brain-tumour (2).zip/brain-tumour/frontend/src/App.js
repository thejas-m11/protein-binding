// src/App.js
import React, { useState } from 'react';
import { Container, Row, Col, Alert, Tabs, Tab } from 'react-bootstrap';
import axios from 'axios';
import UploadForm from './components/UploadForm';
import ImageDisplay from './components/ImageDisplay';
import Results from './components/Results';
import ThreeDViewer from './components/ThreeDViewer';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import ImageUpload from './components/ImageUpload';

function App() {
  const [results, setResults] = useState(null);
  const [slices, setSlices] = useState([]);
  const [error, setError] = useState(null);

  const handleUpload = async (formData) => {
    try {
      const response = await axios.post('http://localhost:5000/api/process', formData);
      setResults(response.data);
      setSlices(prev => [...prev, response.data.original]);
      setError(null);
    } catch (err) {
      setError(err.message);
      setResults(null);
    }
  };

  return (
    <Container className="mt-5">
      <Row>
        <Col>
          <h1 className="text-center mb-4">Brain Tumor Analysis</h1>
          <ImageUpload />
        </Col>
      </Row>
    </Container>
  );
}

export default App;