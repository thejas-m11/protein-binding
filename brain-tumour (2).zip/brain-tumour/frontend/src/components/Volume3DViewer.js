import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';
import './Volume3DViewer.css';

const Volume3DViewer = ({ meshData, metrics }) => {
    const mountRef = useRef(null);

    // Add default values and validation
    const safeMetrics = {
        volume_mm3: metrics?.volume_mm3 || 0,
        surface_area_mm2: metrics?.surface_area_mm2 || 0,
        depth_mm: metrics?.depth_mm || 0,
        perimeter_px: metrics?.perimeter_px || 0,
        circularity: metrics?.circularity || 0,
        confidence: metrics?.confidence || 0,
        num_slices: metrics?.num_slices || 0
    };

    useEffect(() => {
        if (!meshData?.vertices || !mountRef.current) return;

        // Scene setup
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0x000000);

        // Camera setup
        const camera = new THREE.PerspectiveCamera(
            75,
            mountRef.current.clientWidth / mountRef.current.clientHeight,
            0.1,
            1000
        );
        camera.position.z = 5;

        // Renderer setup
        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(mountRef.current.clientWidth, mountRef.current.clientHeight);
        mountRef.current.appendChild(renderer.domElement);

        // Create mesh
        const geometry = new THREE.BufferGeometry();
        const vertices = new Float32Array(meshData.vertices.flat());
        geometry.setAttribute('position', new THREE.BufferAttribute(vertices, 3));
        
        if (meshData.faces) {
            const indices = new Uint32Array(meshData.faces.flat());
            geometry.setIndex(new THREE.BufferAttribute(indices, 1));
        }
        
        geometry.computeVertexNormals();

        const material = new THREE.MeshPhongMaterial({
            color: 0x00ff00,
            opacity: 0.9,
            transparent: true,
            side: THREE.DoubleSide,
        });

        const mesh = new THREE.Mesh(geometry, material);
        scene.add(mesh);

        // Lighting
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
        scene.add(ambientLight);

        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
        directionalLight.position.set(0, 1, 1);
        scene.add(directionalLight);

        // Controls
        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;

        // Center mesh
        geometry.computeBoundingSphere();
        const { center, radius } = geometry.boundingSphere;
        mesh.position.sub(center);
        camera.position.z = radius * 3;

        // Animation
        const animate = () => {
            requestAnimationFrame(animate);
            controls.update();
            renderer.render(scene, camera);
        };
        animate();

        // Cleanup
        return () => {
            mountRef.current?.removeChild(renderer.domElement);
            geometry.dispose();
            material.dispose();
        };
    }, [meshData]);

    return (
        <div className="volume-viewer">
            <div className="render-container" ref={mountRef} />
            {metrics && (
                <div className="metrics-overlay">
                    <h4>Tumor Measurements</h4>
                    <div className="metric-item">
                        <label>Volume:</label>
                        <span>{safeMetrics.volume_mm3.toFixed(2)} mm³</span>
                    </div>
                    <div className="metric-item">
                        <label>Surface Area:</label>
                        <span>{safeMetrics.surface_area_mm2.toFixed(2)} mm²</span>
                    </div>
                    <div className="metric-item">
                        <label>Depth:</label>
                        <span>{safeMetrics.depth_mm.toFixed(2)} mm</span>
                    </div>
                    <div className="metric-item">
                        <label>Perimeter:</label>
                        <span>{safeMetrics.perimeter_px.toFixed(2)} px</span>
                    </div>
                    <div className="metric-item">
                        <label>Circularity:</label>
                        <span>{safeMetrics.circularity.toFixed(3)}</span>
                    </div>
                    <div className="metric-item">
                        <label>Confidence:</label>
                        <span>{(safeMetrics.confidence * 100).toFixed(1)}%</span>
                    </div>
                    <div className="metric-item">
                        <label>Slices:</label>
                        <span>{safeMetrics.num_slices}</span>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Volume3DViewer;