import React, { useState } from 'react';
import { Card, Row, Col } from 'react-bootstrap';
import Volume3DViewer from './Volume3DViewer';
import ClassificationVisual from './ClassificationVisual';
import ImageProcessor from './ImageProcessor';
import Loading from './Loading';
import './ImageUpload.css';

const ImageUpload = () => {
    const [files, setFiles] = useState([]);
    const [results, setResults] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [view3D, setView3D] = useState(false);
    const [processingStage, setProcessingStage] = useState('');

    const handleFileSelect = (event) => {
        const selectedFiles = Array.from(event.target.files);
        // Sort files by name to maintain slice order
        selectedFiles.sort((a, b) => a.name.localeCompare(b.name));
        setFiles(selectedFiles);
        console.log(`Selected ${selectedFiles.length} files`);
    };

    const handleBasicAnalysis = async () => {
        if (!files.length) return;
        
        setLoading(true);
        setError(null);
        setView3D(false);

        const formData = new FormData();
        formData.append('file', files[0]); // Send first slice for basic analysis

        try {
            const response = await fetch('http://localhost:5000/api/process', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();
            if (!response.ok) throw new Error(data.error || 'Processing failed');
            
            setResults(data);
        } catch (err) {
            console.error('Analysis error:', err);
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    const handle3DReconstruction = async () => {
        if (files.length < 1) return;
        
        setLoading(true);
        setError(null);

        const formData = new FormData();
        files.forEach(file => formData.append('slices', file));

        try {
            const response = await fetch('http://localhost:5000/api/reconstruct', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();
            if (!response.ok) throw new Error(data.error || 'Reconstruction failed');

            setResults(prev => ({
                ...prev,
                reconstruction: data
            }));
            setView3D(true);
        } catch (err) {
            console.error('3D reconstruction error:', err);
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    const handleUpload = async (event) => {
        event.preventDefault();
        setLoading(true);
        setError(null);
        
        try {
            setProcessingStage('Preparing image...');
            const formData = new FormData();
            formData.append('file', files[0]);

            setProcessingStage('Analyzing tumor...');
            const response = await fetch('http://localhost:5000/api/process', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || 'Failed to process image');
            }

            setResults(data);
        } catch (err) {
            console.error('Upload error:', err);
            setError(err.message);
        } finally {
            setLoading(false);
            setProcessingStage('');
        }
    };

    const renderResults = () => {
        if (!results) return null;

        return (
            <div className="results-container">
                <div className="classification-section">
                    <h3>Tumor Analysis</h3>
                    <div className="tumor-info">
                        <div className="info-item">
                            <label>Tumor Type:</label>
                            <span className="tumor-type">{results.tumor_type || 'Unknown'}</span>
                        </div>
                        <div className="info-item">
                            <label>Confidence:</label>
                            <span className="confidence">
                                {((results.confidence || 0) * 100).toFixed(1)}%
                            </span>
                        </div>
                    </div>
                </div>

                <ImageProcessor 
                    originalImage={results.slices?.[0]?.original}
                    enhancedImages={results.slices?.[0]?.enhanced}
                />

                {results.analysis?.class_probabilities && (
                    <ClassificationVisual 
                        probabilities={results.analysis.class_probabilities} 
                    />
                )}

                <div className="metrics-section">
                    <h3>Measurements</h3>
                    <div className="metrics-grid">
                        <div className="metric-item">
                            <label>Area:</label>
                            <span>{results?.analysis?.measurements?.area_pixels.toFixed(2)} px²</span>
                        </div>
                        <div className="metric-item">
                            <label>Perimeter:</label>
                            <span>{results?.analysis?.measurements?.perimeter_pixels.toFixed(2)} px</span>
                        </div>
                        <div className="metric-item">
                            <label>Circularity:</label>
                            <span>{results?.analysis?.measurements?.circularity.toFixed(3)}</span>
                        </div>
                    </div>
                </div>
            </div>
        );
    };

    return (
        <div className="upload-container">
            <div className="upload-section">
                <h3>Brain Tumor Analysis</h3>
                <input
                    type="file"
                    onChange={handleFileSelect}
                    multiple
                    accept="image/*"
                    className="file-input"
                />
                <div className="button-group">
                    <button
                        onClick={handleBasicAnalysis}
                        disabled={!files.length || loading}
                        className="analysis-button"
                    >
                        Basic Analysis
                    </button>
                    <button
                        onClick={handle3DReconstruction}
                        disabled={!files.length || loading}
                        className="reconstruction-button"
                    >
                        3D Reconstruction
                    </button>
                </div>
            </div>

            {loading && <Loading message={processingStage} />}
            {error && <div className="error-message">{error}</div>}

            {results && !view3D && (
                <div className="basic-analysis">
                    <Row>
                        <Col md={6}>
                            <Card>
                                <Card.Header>Original Image</Card.Header>
                                <Card.Body>
                                    <img
                                        src={`data:image/png;base64,${results.slices[0].original}`}
                                        alt="Original"
                                        className="result-image"
                                    />
                                </Card.Body>
                            </Card>
                        </Col>
                        <Col md={6}>
                            <Card>
                                <Card.Header>Enhanced Image</Card.Header>
                                <Card.Body>
                                    <img
                                        src={`data:image/png;base64,${results.slices[0].enhanced.clahe}`}
                                        alt="Enhanced"
                                        className="result-image"
                                    />
                                </Card.Body>
                            </Card>
                        </Col>
                    </Row>
                </div>
            )}

            {results?.reconstruction && view3D && (
                <div className="reconstruction-view">
                    <Volume3DViewer
                        meshData={results.reconstruction.mesh}
                        metrics={results.reconstruction.metrics}
                    />
                </div>
            )}

            {renderResults()}
        </div>
    );
};

export default ImageUpload;