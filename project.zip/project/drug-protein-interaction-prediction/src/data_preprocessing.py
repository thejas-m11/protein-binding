import pandas as pd
from Bio import SeqIO
import numpy as np
from sklearn.preprocessing import LabelEncoder

def encode_sequence(sequence, max_length=1000):
    """Convert sequence to numerical encoding"""
    # Create label encoder for amino acids/atoms
    encoder = LabelEncoder()
    sequence_list = list(sequence)
    encoded = encoder.fit_transform(sequence_list)
    
    # Pad sequence
    if len(encoded) < max_length:
        encoded = np.pad(encoded, (0, max_length - len(encoded)))
    else:
        encoded = encoded[:max_length]
    
    return encoded

def load_and_preprocess_data(data_path):
    """Load and preprocess the dataset"""
    df = pd.read_csv(data_path)
    
    # Encode sequences
    X_protein = np.array([encode_sequence(seq) for seq in df['protein_sequence']])
    X_drug = np.array([encode_sequence(seq) for seq in df['drug_sequence']])
    y = df['interaction'].values
    
    return X_protein, X_drug, y