# src/app.py
from flask import Flask, render_template, request, jsonify
import numpy as np
from data_preprocessing import encode_sequence
from tensorflow.keras.models import load_model
import os
from rdkit import Chem
from rdkit.Chem import AllChem

app = Flask(__name__, template_folder='../templates')

# Example sequences
EXAMPLE_SEQUENCES = {
    'protein': 'MAEGEITTFTALTEKFNLPPGNYKKPKLLYCSNGGHFLRILPDGTVDGTRDRSDQHIQLQLSAESVGEVYIKSTETGQYLAMDTDGLLYGSQTPNEECLFLERLEENHYNTYISKKHAEKNWFVGLKKNGSCKRGPRTHYGQKAILFLPLPV',
    'drug': 'CC1=CC=C(C=C1)CN2C=NC3=C2N=CN=C3N'
}

def get_mol_structure(smiles):
    """Convert SMILES to 3D coordinates"""
    mol = Chem.MolFromSmiles(smiles)
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol)
    AllChem.MMFFOptimizeMolecule(mol)
    return Chem.MolToMolBlock(mol)

@app.route('/')
def index():
    return render_template('index.html', examples=EXAMPLE_SEQUENCES)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.json
        protein_seq = data['proteinSequence']
        drug_seq = data['drugSequence']

        # Get prediction
        prediction = model.predict([
            np.array([encode_sequence(protein_seq)]),
            np.array([encode_sequence(drug_seq)])
        ])

        # Get 3D structure
        mol_block = get_mol_structure(drug_seq)

        return jsonify({
            'prediction': float(prediction[0][0]),
            'probability': float(prediction[0][0] * 100),
            'interaction': 'Likely' if prediction[0][0] > 0.5 else 'Unlikely',
            'mol_block': mol_block
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/visualize', methods=['POST'])
def visualize():
    try:
        data = request.json
        drug_seq = data['drugSequence']
        
        # Generate 3D structure
        pdb_data = get_3d_structure(drug_seq)
        viewer_html = generate_3d_visualization(pdb_data)
        
        return jsonify({
            'success': True,
            'viewer_html': viewer_html
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

if __name__ == '__main__':
    # Load model
    model_path = '../models/drug_protein_model.h5'
    if not os.path.exists(model_path):
        raise FileNotFoundError("Model not found. Please run train_model.py first.")
    
    model = load_model(model_path)
    app.run(debug=True)