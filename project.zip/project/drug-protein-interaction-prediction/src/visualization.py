# src/visualization.py
from rdkit import Chem
from rdkit.Chem import AllChem
import py3Dmol

def get_3d_structure(smiles):
    """Generate 3D structure from SMILES"""
    try:
        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            raise ValueError("Invalid SMILES string")
            
        mol = Chem.AddHs(mol)
        AllChem.EmbedMolecule(mol, randomSeed=42)
        AllChem.MMFFOptimizeMolecule(mol)
        
        return Chem.MolToPDBBlock(mol)
    except Exception as e:
        raise Exception(f"Error generating 3D structure: {str(e)}")

def generate_3d_visualization(pdb_data):
    """Generate HTML/JS code for 3D visualization"""
    viewer_html = f"""
    <div style="height: 400px; width: 100%; position: relative;" id="viewer"></div>
    <script>
        let viewer = $3Dmol.createViewer(document.getElementById("viewer"), {{
            backgroundColor: 'white'
        }});
        viewer.addModel(`{pdb_data}`, "pdb");
        viewer.setStyle({{}}, {{stick:{{}}, sphere:{{radius: 0.5}}}});
        viewer.zoomTo();
        viewer.render();
    </script>
    """
    return viewer_html